const express = require('express');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');
const app = express();
const PORT = 5000;

const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

app.use(bodyParser.json());

app.post('/send-notification', (req, res) => {
  const { token, title, body } = req.body;

  const message = {
    notification: { title, body },
    token,
  };

  admin
    .messaging()
    .send(message)
    .then(response => res.status(200).send('Notification sent'))
    .catch(error => res.status(500).send('Error sending notification: ' + error));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
