# React Native Push Notification App

## Features
- Real-time push notifications using Firebase Cloud Messaging (FCM)
- Native Android module in Java
- Deep linking from notifications
- Badge count (using `react-native-notifications`)
- Backend simulation with Express

## How to Run
1. Install dependencies
2. Run backend using `node backend/server.js`
3. Launch app with `npx react-native run-android`

## Submission
- Upload demo video to shared Drive
- Share GitHub repo with your name
