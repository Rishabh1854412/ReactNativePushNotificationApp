package com.notificationapp;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;

public class CustomModule extends ReactContextBaseJavaModule {
  CustomModule(ReactApplicationContext context) {
    super(context);
  }

  @Override
  public String getName() {
    return "CustomModule";
  }
}
